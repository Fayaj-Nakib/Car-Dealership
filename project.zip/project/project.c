#include<stdio.h>
int main()
{
    printf("\t\t\t\t\t\tWELCOME TO OUR NO MAN SHOWROOM\n");

    printf("Please inform us about your Budget :\n");
    while(1)
    {
        char s;
        FILE *br = fopen("budget.txt","r");
        while(1)
        {
            s = fgetc(br);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(br);
        printf("\n");


        int r;
        printf("Please choose your range: ");
        scanf("%d",&r);
        printf("\n");
        if(r==1)
        {
            under_30_lakh();
        }
        else if(r==2)
        {
            t_30_to_50();
        }
        else if(r==3)
        {
            t_50_to_100();
        }
        else if(r==4)
        {
            above_1_cr();
        }

        printf("If you want to buy another car press p\n If you are done then press c\n");
        char x,y;
        printf("Give us your decision: ");
        scanf("%c%c",&x,&y);
        if(y=='p')
        {
            continue;
        }
        else if(y=='c')
        {
            break;
        }
    }
    printf("\t\t\t\t\tThank you,Come again.");
    return 0;
}
int under_30_lakh()
{
    int t;
    printf("We have those type of car in this range:\n");
    char s;
    FILE *u3l = fopen("under30type.txt","r");
    while(1)
    {
        s = fgetc(u3l);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(u3l);
    printf("\n");
    printf("Please choose your type: ");
    scanf("%d",&t);
    if(t==1)
    {
        printf("You choosed SUV.\nLet's see what we have:\n");
        suv_brands_under_30();
    }
    else
    {
        printf("You choosed SEDAN.\nLet's see what we have:\n");
        sedan_brands_under_30();
    }
    return 0;
}
int suv_brands_under_30()
{
    int b;
    printf("Choose your brand :\n");

    char s;
    FILE *svu30 = fopen("under30suvbrands.txt","r");
    while(1)
    {
        s = fgetc(svu30);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(svu30);
    printf("\n");
    printf("Please choose your brand: ");
    scanf("%d",&b);
    if(b==1)
    {
        printf("you have choosed Hyundai.lets see what we have:\n");
        char s;
        FILE *suhy30 = fopen("u30suvhyundai.txt","r");
        while(1)
        {
            s = fgetc(suhy30);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(suhy30);
        printf ("\n");
        su_hy_30();
    }
    else if(b==2)
    {
        printf("you have choosed Volkswagen.lets see what we have:\n");
        char s;
        FILE *suvw30 = fopen("u30suvvolkswagen.txt","r");
        while(1)
        {
            s = fgetc(suvw30);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(suvw30);
        printf("\n");
        su_vw_30();
    }
    else
    {
        printf("you have choosed Jeep.lets see what we have:\n");
        char s;
        FILE *suj30 = fopen("u30suvjeep.txt","r");
        while(1)
        {
            s = fgetc(suj30);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(suj30);
        printf("\n");
        su_j_30();

    }
    return 0;
}


int sedan_brands_under_30()
{
    int b;
    printf("Choose your brand :\n");

    char s;
    FILE *snu30 = fopen("under30sedanbrands.txt","r");
    while(1)
    {
        s = fgetc(snu30);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(snu30);
    printf("\n");
    printf("Please choose your brand: ");
    scanf("%d",&b);
    printf("\n");
    if(b==1)
    {
        printf("you have choosed Hyundai.lets see what we have:\n");
        char s;
        FILE *hydi30 = fopen("u30sedanhyundai.txt","r");
        while(1)
        {
            s = fgetc(hydi30);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(hydi30);
        printf("\n");
        u30_hyundai();

    }
    else
    {
        printf("you have choosed Honda.lets see what we have:\n");
        char s;
        FILE *hnda30 = fopen("u30sedanhonda.txt","r");
        while(1)
        {
            s = fgetc(hnda30);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(hnda30);
        printf ("\nYou choosed Honda City.\n");
        char m;
        FILE *hc = fopen("hondacity.txt","r");
        while(1)
        {
            m = fgetc(hc);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(hc);
        printf("\nHeres the documents & key.\n");
    }
    return 0;
}
int u30_hyundai()
{
    int h;
    printf("Please choose your model: ");
    scanf("%d",&h);
    printf("\n");
    if(h==1)
    {
        printf("You choosed Hyundai Verna.\n");
        char m;
        FILE *hv = fopen("hyundaiverna.txt","r");
        while(1)
        {
            m = fgetc(hv);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(hv);

        printf ("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Hyundai Elantra.\n");
        char m;
        FILE *he = fopen("hyundaielantra.txt","r");
        while(1)
        {
            m = fgetc(he);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(he);

        printf ("\nHeres the documents & key.\n");
    }
    return 0;
}
int su_hy_30()
{
    int h;
    printf("Please choose your model: ");
    scanf("%d",&h);
    printf("\n");
    if(h==1)
    {
        printf("You choosed Hyundai Creta.\n");
        char m;
        FILE *hc = fopen("hyundaicreta.txt","r");
        while(1)
        {
            m = fgetc(hc);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(hc);
        printf ("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Hyundai Venue.\n");
        char m;
        FILE *venue = fopen("hyundaivenue.txt","r");
        while(1)
        {
            m = fgetc(venue);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(venue);
        printf ("\nHeres the documents & key.\n");
    }
    return 0;
}
int su_vw_30()
{
    printf("You choosed Volkswagen T-Roc.\n");
    char m;
    FILE *vr = fopen("volkswagentroc.txt","r");
    while(1)
    {
        m = fgetc(vr);
        if (m == EOF) break;
        printf("%c",m);
    }
    fclose(vr);
    printf("\nHeres the documents & key.\n");
    return 0;
}
int su_j_30()
{
    int j;
    printf("Please choose your model: ");
    scanf("%d",&j);
    printf("\n");
    if(j==1)
    {
        printf("You choosed Jeep Compass.\n");
        char m;
        FILE *jp = fopen("jeepcompass.txt","r");
        while(1)
        {
            m = fgetc(jp);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(jp);
        printf ("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Jeep Compass Trailhawk.\n");
        char m;
        FILE *jpt = fopen("jeepcompasstrailhawk.txt","r");
        while(1)
        {
            m = fgetc(jpt);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(jpt);
        printf ("\nHeres the documents & key.\n");
    }
    return 0;
}


//above_1_cr



int above_1_cr()
{
    char s;
    FILE *cr = fopen("above1crtypes.txt","r");
    while(1)
    {
        s = fgetc(cr);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(cr);
    printf("\n");
    int t;
    printf("Please choose your model: ");
    scanf("%d",&t);
    printf("\n");
    if(t==1)
    {
        above_1_cr_suv();
    }
    else if(t==2)
    {
        above_1_cr_sedan();
    }
    else if (t==3)
    {
        above_1_cr_convertible();
    }
    else if (t==4)
    {
        above_1_cr_luxury();
    }
    else
    {
        above_1_cr_super();
    }
    return 0;
}
int above_1_cr_suv()
{
    char s;
    FILE *crsuv = fopen("above1crsuvbrands.txt","r");
    while(1)
    {
        s = fgetc(crsuv);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(crsuv);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    if(m==1)
    {
        printf("You choosed Range Rover Sport 3.\n");
        char m;
        FILE *rrs = fopen("rangeroversport3.txt","r");
        while(1)
        {
            m = fgetc(rrs);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(rrs);
        printf ("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Lamborghini Urus.\n");
        char m;
        FILE *lu = fopen("lamborghiniurusv8.txt","r");
        while(1)
        {
            m = fgetc(lu);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(lu);
        printf ("\nHeres the documents & key.\n");
    }
    return 0;
}
int above_1_cr_sedan()
{
    char s;
    FILE *crsed = fopen("above1crsedanbrands.txt","r");
    while(1)
    {
        s = fgetc(crsed);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(crsed);
    printf("\n");
    printf("You choosed Audi A8.\n");
    char m;
    FILE *aa = fopen("audia8.txt","r");
    while(1)
    {
        m = fgetc(aa);
        if (m == EOF) break;
        printf("%c",m);
    }
    fclose(aa);
    printf ("\nHeres the documents & key.\n");
    return 0;
}
int above_1_cr_convertible()
{
    char s;
    FILE *crcon = fopen("above1crconvertiblebrands.txt","r");
    while(1)
    {
        s = fgetc(crcon);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(crcon);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed Aston Martin DB11(v8).\n");
        char m;
        FILE *am= fopen("astonmartindb11v8.txt","r");
        while(1)
        {
            m = fgetc(am);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(am);
        printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed Bently Continental GT Converible(V8).\n");
        char m;
        FILE *bc = fopen("bentleycontinentalgtv8convertible.txt","r");
        while(1)
        {
            m = fgetc(bc);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(bc);
        printf("\nHeres the documents & key.\n");
    }
    else if(m==3)
    {
        printf("You choosed Ferrari Portofino.\n");
        char m;
        FILE *fp = fopen("ferrariportofino.txt","r");
        while(1)
        {
            m = fgetc(fp);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(fp);
        printf ("\nHeres the documents & key.\n");
    }
    else if(m==4)
    {
        printf("You choosed Lamborghini Huracan EVO spyder.\n");
        char m;
        FILE *lhe = fopen("lamborghinihuracanevospyder.txt","r");
        while(1)
        {
            m = fgetc(lhe);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(lhe);
        printf ("\nHeres the documents & key.\n");
    }
    else if(m==5)
    {
        printf("You choosed Porsche 911 carrera.\n");
        char m;
        FILE *pc = fopen("porsche911carrera.txt","r");
        while(1)
        {
            m = fgetc(pc);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(pc);

        printf ("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Rolls Royce Dawn.\n");

        char m;
        FILE *rrd = fopen("rollsroycedawn.txt","r");
        while(1)
        {
            m = fgetc(rrd);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(rrd);
        printf ("\nHeres the documents & key.\n");
    }
    return 0;
}
int above_1_cr_luxury()
{
    char s;
    FILE *crl = fopen("above1crluxurybrands.txt","r");
    while(1)
    {
        s = fgetc(crl);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(crl);
    printf("\n");
    int m;
    scanf("%d",&m);
    if(m==1)
    {
        printf("You choosed Bentley Flying Spur V8.\n");
        char m;
        FILE *bf = fopen("bentleyflyingspurv8.txt","r");
        while(1)
        {
            m = fgetc(bf);
            if (m == EOF) break;
            printf("%c",m);
        }
        fclose(bf);
        printf ("\nHeres the documents & key.\n");
    }
    else
    {
        above_1_cr_luxury_rr();
    }
    return 0;
}
int above_1_cr_luxury_rr()
{
    char s;
    FILE *crlr= fopen("a1luxuryrr.txt","r");
    while(1)
    {
        s = fgetc(crlr);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(crlr);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed Rolls-Royce Ghost v 12.\n");
        char s;
    FILE *rrg= fopen("rollsroyceghostv12.txt","r");
    while(1)
    {
        s = fgetc(rrg);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(rrg);
    printf("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Rolls Royce Phantom.\n");
        char s;
    FILE *rrp= fopen("rollsroycephantom.txt","r");
    while(1)
    {
        s = fgetc(rrp);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(rrp);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}
int above_1_cr_super()
{
    char s;
    FILE *crsp= fopen("above1crsuperbrands.txt","r");
    while(1)
    {
        s = fgetc(crsp);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(crsp);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed Aston Martin Vantage v8.\n");
        char s;
    FILE *amv= fopen("astonmartinvantagev8.txt","r");
    while(1)
    {
        s = fgetc(amv);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(amv);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed Ferrari Roma.\n");
        char s;
    FILE *fr= fopen("ferrariroma.txt","r");
    while(1)
    {
        s = fgetc(fr);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(fr);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed Lamborghini Aventador S .\n");
         char s;
    FILE *las= fopen("lamborghinisventadors.txt","r");
    while(1)
    {
        s = fgetc(las);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(las);
    printf("\nHeres the documents & key.\n");
    }
    else
    {
        printf("You choosed Nissan GT-R.\n");
         char s;
    FILE *gtr= fopen("nissangtr.txt","r");
    while(1)
    {
        s = fgetc(gtr);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(gtr);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}


//50-100


int t_50_to_100()
{
    char s;
    FILE *t = fopen("50-100TYPES.txt","r");
    while(1)
    {
        s = fgetc(t);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(t);
    printf("\n");
    int d;
    printf("Please choose your type: ");
    scanf("%d",&d);
    printf("\n");
    if(d==1)
    {
        t_50_to_100_suv();
    }
    else if(d==2)
    {
        t_50_to_100_sedan();
    }
    else if (d==3)
    {
        t_50_to_100_sport();
    }
    else if (d==4)
    {
        t_50_to_100_convertible();
    }
    return 0;
}
int t_50_to_100_suv()
{
    char s;
    FILE *tsu = fopen("50-100suvbrands.txt","r");
    while(1)
    {
        s = fgetc(tsu);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tsu);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed BMW X3 M.\n");
         char s;
    FILE *x3= fopen("bmwx3m.txt","r");
    while(1)
    {
        s = fgetc(x3);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(x3);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed Jaguar F-PACE.\n");
         char s;
    FILE *jf= fopen("jaguarfpace.txt","r");
    while(1)
    {
        s = fgetc(jf);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(jf);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==3)
    {
        printf("You choosed Mercedes-Benz GLE 400d.\n");
         char s;
    FILE *gle= fopen("mercedesbenzgle400d.txt","r");
    while(1)
    {
        s = fgetc(gle);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(gle);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==4)
    {
        printf("You choosed Porsche Macan.\n");
         char s;
    FILE *pm= fopen("porschemacan.txt","r");
    while(1)
    {
        s = fgetc(pm);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(pm);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==5)
    {
        printf("You choosed Range rover velar.\n");
         char s;
    FILE *rrv= fopen("rangerovervelar.txt","r");
    while(1)
    {
        s = fgetc(rrv);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(rrv);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}
int t_50_to_100_sedan()
{
    char s;
    FILE *tse = fopen("50-100sedanbrands.txt","r");
    while(1)
    {
        s = fgetc(tse);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tse);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed Audi A6.\n");
         char s;
    FILE *a6= fopen("audia6.txt","r");
    while(1)
    {
        s = fgetc(a6);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(a6);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed BMW M2.\n");
         char s;
    FILE *m2= fopen("bmwm2.txt","r");
    while(1)
    {
        s = fgetc(m2);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(m2);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==3)
    {
        printf("You choosed Jaguar XF.\n");
         char s;
    FILE *jxf= fopen("jaguarxf.txt","r");
    while(1)
    {
        s = fgetc(jxf);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(jxf);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==4)
    {
        printf("You choosed Lexus ES 300h.\n");
         char s;
    FILE *les= fopen("lexuses300h.txt","r");
    while(1)
    {
        s = fgetc(les);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(les);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==5)
    {
        printf("You choosed Mercedes Benz AMG E 350d.\n");
         char s;
    FILE *e350d= fopen("mercedesbenzamge350d.txt","r");
    while(1)
    {
        s = fgetc(e350d);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(e350d);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==6)
    {
        printf("You choosed Volvo S90.\n");
         char s;
    FILE *s90= fopen("volvos90.txt","r");
    while(1)
    {
        s = fgetc(s90);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(s90);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}
int t_50_to_100_sport()
{
    char s;
    FILE *tsp = fopen("50-100sportsbrand.txt","r");
    while(1)
    {
        s = fgetc(tsp);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tsp);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed BMW 5 series 530d M sport.\n");
         char s;
    FILE *b530= fopen("bmw5series530dmsport.txt","r");
    while(1)
    {
        s = fgetc(b530);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(b530);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed BMW GT 630d M Sport.\n");
         char s;
    FILE *gt630= fopen("bmwgt630dmsport.txt","r");
    while(1)
    {
        s = fgetc(gt630);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(gt630);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}


int  t_50_to_100_convertible()
{
    char s;
    FILE *tcv= fopen("50-100convertiblebrand.txt","r");
    while(1)
    {
        s = fgetc(tcv);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tcv);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed BMW Z4 M40i.\n");
         char s;
    FILE *z4= fopen("bmwz4m40i.txt","r");
    while(1)
    {
        s = fgetc(z4);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(z4);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}


//30-50



int t_30_to_50()
{
    char s;
    FILE *tps = fopen("30-50TYPES.txt","r");
    while(1)
    {
        s = fgetc(tps);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tps);
    printf("\n");
    int d;
    printf("Please choose your type: ");
    scanf("%d",&d);
    printf("\n");
    if(d==1)
    {
        t_30_to_50_suv();
    }
    else if(d==2)
    {
        t_30_to_50_sedan();
    }
    else if (d==3)
    {
        t_30_to_50_sport();
    }
    else if (d==4)
    {
        t_30_to_50_convertible();
    }
    return 0;
}
int t_30_to_50_suv()
{
    char s;
    FILE *tspsu = fopen("30-50suvbrands.txt","r");
    while(1)
    {
        s = fgetc(tspsu);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tspsu);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed BMW X1.\n");
        char s;
    FILE *x1= fopen("bmwx1.txt","r");
    while(1)
    {
        s = fgetc(x1);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(x1);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed Ford Endeavour.\n");
        char s;
    FILE *fe= fopen("fordendeavour.txt","r");
    while(1)
    {
        s = fgetc(fe);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(fe);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==3)
    {
        printf("You choosed Toyota Fortuner.\n");
        char s;
    FILE *tf= fopen("toyotafortuner.txt","r");
    while(1)
    {
        s = fgetc(tf);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tf);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==4)
    {
        printf("You choosed Volkswagen Tiguan Allspace.\n");
        char s;
    FILE *vta= fopen("volkswagentiguanallspace.txt","r");
    while(1)
    {
        s = fgetc(vta);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(vta);
    printf("\nHeres the documents & key.\n");
    }
    return 0;
}
int t_30_to_50_sedan()
{
    char s;
    FILE *tspse = fopen("30-50sedanbrands.txt","r");
    while(1)
    {
        s = fgetc(tspse);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tspse);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed Audi A4.\n");
        char s;
    FILE *a4= fopen("audia4.txt","r");
    while(1)
    {
        s = fgetc(a4);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(a4);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==2)
    {
        printf("You choosed Jaguar XE .\n");
        char s;
    FILE *jxe= fopen("jaguarxe.txt","r");
    while(1)
    {
        s = fgetc(jxe);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(jxe);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==3)
    {
        printf("You choosed Mercedes  Benz a 200.\n");
        char s;
    FILE *a200= fopen("mercedesbenza200.txt","r");
    while(1)
    {
        s = fgetc(a200);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(a200);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==4)
    {
        printf("You choosed Toyota Camry.\n");
        char s;
    FILE *tc= fopen("toyotacamry.txt","r");
    while(1)
    {
        s = fgetc(tc);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tc);
    printf("\nHeres the documents & key.\n");
    }
    else if(m==5)
    {
        printf("You choosed Volvo S60.\n");
        char s;
    FILE *vs6= fopen("volvos60.txt","r");
    while(1)
    {
        s = fgetc(vs6);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(vs6);
    printf("\nHeres the documents & key.\n");
    }

    return 0;
}
int t_30_to_50_sport()
{
    char s;
    FILE *tspsp = fopen("30-50SPORTSBRAND.txt","r");
    while(1)
    {
        s = fgetc(tspsp);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tspsp);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed BMW 3 series 330i M sport.\n");
         char s;
    FILE *bmwim= fopen("bmw3series330imsport.txt","r");
    while(1)
    {
        s = fgetc(bmwim);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(bmwim);
    printf("\n");
    printf("\nHeres the documents & key.\n");

    }
    else if(m==2)
    {
        printf("You choosed BMW  2 Black Shadow Edition.\n");
        char s;
    FILE *bmwbs= fopen("bmw2blackshadowedition.txt","r");
    while(1)
    {
        s = fgetc(bmwbs);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(bmwbs);
        printf("\nHeres the documents & key.\n");
    }
    return 0;
}


int  t_30_to_50_convertible()
{
    char s;
    FILE *tscv= fopen("30-50convertiblebrand.txt","r");
    while(1)
    {
        s = fgetc(tscv);
        if (s == EOF) break;
        printf("%c",s);
    }
    fclose(tscv);
    printf("\n");
    int m;
    printf("Please choose your model: ");
    scanf("%d",&m);
    printf("\n");
    if(m==1)
    {
        printf("You choosed MINI Cooper Convertible.\n");
        char s;
        FILE *mcc= fopen("minicooperconvertible.txt","r");
        while(1)
        {
            s = fgetc(mcc);
            if (s == EOF) break;
            printf("%c",s);
        }
        fclose(mcc);
        printf("\n");
        printf("\nHeres the documents & key.\n");
    }
    return 0;
}
